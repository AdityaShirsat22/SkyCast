package com.cfs.whether_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhetherAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhetherAppApplication.class, args);
	}

}
