package com.cfs.whether_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhetherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
